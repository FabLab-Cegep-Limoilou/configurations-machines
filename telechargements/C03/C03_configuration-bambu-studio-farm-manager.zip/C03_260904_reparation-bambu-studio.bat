@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Bambu Studio - Correctif multi-session V5

echo.
echo ================================================================
echo  Bambu Studio - Correctif multi-session V5
echo ================================================================
echo Utilisateur : %USERDOMAIN%\%USERNAME%
echo.

set "SELF=%~f0"

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$p=$env:SELF; $c=Get-Content -LiteralPath $p; $m=[Array]::IndexOf($c,'#__POWERSHELL_BELOW__'); if($m -lt 0){exit 90}; $s=$m+1; if($s -ge $c.Count){exit 91}; $code=($c[$s..($c.Count-1)] -join [Environment]::NewLine); & ([scriptblock]::Create($code))"

set "RC=%ERRORLEVEL%"

echo.
if not "%RC%"=="0" (
    echo ================================================================
    echo  ECHEC DU CORRECTIF - CODE %RC%
    echo ================================================================
    echo.
    echo Envoie une capture de cette fenetre.
    echo.
    pause
    endlocal
    exit /b %RC%
)

echo ================================================================
echo  CORRECTIF TERMINE
echo ================================================================
echo.
echo Verifie maintenant que Bambu Studio s'ouvre normalement.
echo.
pause
endlocal
exit /b 0

#__POWERSHELL_BELOW__

$ErrorActionPreference = 'Stop'

$localRoot   = Join-Path $env:LOCALAPPDATA 'FabLab\BambuStudio'
$master      = Join-Path $localRoot 'BambuStudio.conf'
$userDir     = Join-Path $env:APPDATA 'BambuStudio'
$userCfg     = Join-Path $userDir 'BambuStudio.conf'
$hashMarker  = Join-Path $userDir 'FabLab-BambuStudio.sha256'
$safeFolder  = Join-Path $localRoot 'Downloads'
$studio      = 'C:\Program Files\Bambu Studio\bambu-studio.exe'
$logFile     = Join-Path $localRoot 'Repair-V5.log'

function Log([string]$Message) {
    $line = '[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    Write-Host $Message
    try {
        Add-Content -LiteralPath $logFile -Value $line -Encoding UTF8
    }
    catch {}
}

function Fail([int]$Code, [string]$Message) {
    Log ('ERREUR : ' + $Message)
    Write-Host ''
    Write-Host ('Journal : ' + $logFile)
    exit $Code
}

function Get-BambuChecksum([string]$JsonText) {
    # Bambu/Boost lit le fichier Windows en mode texte.
    # Les CRLF sont donc normalises en LF avant le calcul MD5.
    $normalized = $JsonText.Replace("`r`n", "`n").Replace("`r", "`n")
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($normalized)

    $md5 = [System.Security.Cryptography.MD5]::Create()
    try {
        $hash = $md5.ComputeHash($bytes)
    }
    finally {
        $md5.Dispose()
    }

    return ([System.BitConverter]::ToString($hash)).Replace('-', '').ToUpperInvariant()
}

try {
    New-Item -ItemType Directory -Path $localRoot -Force | Out-Null
    New-Item -ItemType Directory -Path $userDir -Force | Out-Null
    New-Item -ItemType Directory -Path $safeFolder -Force | Out-Null
}
catch {
    Fail 20 ('Impossible de preparer les dossiers utilisateur : ' + $_.Exception.Message)
}

Log ('Profil Windows : ' + $env:USERDOMAIN + '\' + $env:USERNAME)
Log ('Configuration maitre : ' + $master)
Log ('Configuration active : ' + $userCfg)
Log ('Dossier telechargement : ' + $safeFolder)

if (-not (Test-Path -LiteralPath $master)) {
    Fail 21 ('Configuration maitre introuvable : ' + $master)
}

if (-not (Test-Path -LiteralPath $studio)) {
    Fail 22 ('Bambu Studio introuvable : ' + $studio)
}

Log '1/6 - Fermeture de Bambu Studio...'
Get-Process -Name 'bambu-studio','BambuStudio' -ErrorAction SilentlyContinue |
    Where-Object { $_.SessionId -eq (Get-Process -Id $PID).SessionId } |
    Stop-Process -Force -ErrorAction SilentlyContinue

Log '2/6 - Sauvegarde de la configuration actuelle...'

if (Test-Path -LiteralPath $userCfg) {
    $backup = $userCfg + '.avant-V5.bak'
    try {
        Copy-Item -LiteralPath $userCfg -Destination $backup -Force
        Log ('Sauvegarde creee : ' + $backup)
    }
    catch {
        Fail 23 ('Sauvegarde impossible : ' + $_.Exception.Message)
    }
}

Log '3/6 - Blocage de la recopie automatique de la configuration maitre...'

try {
    $masterSha = (Get-FileHash -LiteralPath $master -Algorithm SHA256).Hash
    [System.IO.File]::WriteAllText(
        $hashMarker,
        $masterSha,
        [System.Text.Encoding]::ASCII
    )
}
catch {
    Fail 24 ('Impossible de creer le marqueur de synchronisation : ' + $_.Exception.Message)
}

Log '4/6 - Creation de la configuration propre a cette session...'

try {
    # Toujours repartir de la configuration maitre Fab Lab.
    $text = [System.IO.File]::ReadAllText($master)

    # BambuStudio.conf contient du JSON suivi d'une ligne:
    # # MD5 checksum ...
    $lastBrace = $text.LastIndexOf('}')
    if ($lastBrace -lt 0) {
        throw 'Derniere accolade JSON introuvable.'
    }

    $json = $text.Substring(0, $lastBrace + 1)

    # Echappement JSON du chemin Windows.
    $safeJson = $safeFolder.Replace('\', '\\')

    $downloadPattern = '("download_path"\s*:\s*)"[^"]*"'
    if (-not [regex]::IsMatch($json, $downloadPattern)) {
        throw 'Cle download_path introuvable.'
    }

    $json = [regex]::Replace(
        $json,
        $downloadPattern,
        {
            param($match)
            $match.Groups[1].Value + '"' + $safeJson + '"'
        },
        1
    )

    $backupPattern = '("last_backup_path"\s*:\s*)"[^"]*"'
    if ([regex]::IsMatch($json, $backupPattern)) {
        $json = [regex]::Replace(
            $json,
            $backupPattern,
            {
                param($match)
                $match.Groups[1].Value + '""'
            },
            1
        )
    }

    if ($json -match '(?i)[A-Z]:\\\\Users\\\\') {
        throw 'Un ancien chemin utilisateur nominatif est encore present.'
    }

    $checksum = Get-BambuChecksum $json

    # Bambu ecrit le JSON puis une ligne checksum.
    # On sauvegarde en CRLF; Bambu normalisera en LF lors de la lecture.
    $jsonWindows = $json.Replace("`r`n", "`n").Replace("`r", "`n").Replace("`n", "`r`n")
    $output = $jsonWindows + "`r`n# MD5 checksum " + $checksum + "`r`n"

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($userCfg, $output, $utf8NoBom)

    Log ('Checksum Bambu genere : ' + $checksum)
}
catch {
    Fail 25 ('Creation de BambuStudio.conf impossible : ' + $_.Exception.Message)
}

Log '5/6 - Verification du fichier genere...'

try {
    $written = [System.IO.File]::ReadAllText($userCfg)
    $brace = $written.LastIndexOf('}')
    if ($brace -lt 0) {
        throw 'JSON absent apres ecriture.'
    }

    $writtenJson = $written.Substring(0, $brace + 1)
    $expectedChecksum = Get-BambuChecksum $writtenJson

    $checksumMatch = [regex]::Match(
        $written,
        '(?im)^# MD5 checksum ([0-9A-F]{32})\s*$'
    )

    if (-not $checksumMatch.Success) {
        throw 'Ligne MD5 Bambu absente.'
    }

    $storedChecksum = $checksumMatch.Groups[1].Value.ToUpperInvariant()

    if ($storedChecksum -ne $expectedChecksum) {
        throw ('Checksum invalide. Attendu=' + $expectedChecksum + ' Stocke=' + $storedChecksum)
    }

    if ($writtenJson -match '(?i)[A-Z]:\\\\Users\\\\') {
        throw 'Un ancien chemin utilisateur nominatif est encore present.'
    }

    if ($writtenJson -notmatch [regex]::Escape($safeJson)) {
        throw 'Nouveau download_path absent.'
    }

    Log ('Verification MD5 : OK - ' + $storedChecksum)
    Log ('download_path : ' + $safeFolder)
}
catch {
    Fail 26 ('Verification impossible : ' + $_.Exception.Message)
}

Log '6/6 - Lancement de Bambu Studio...'

try {
    Start-Process -FilePath $studio
}
catch {
    Fail 27 ('Bambu Studio ne peut pas etre lance : ' + $_.Exception.Message)
}

Log 'Correctif termine avec succes.'
Log ('Journal : ' + $logFile)

exit 0
