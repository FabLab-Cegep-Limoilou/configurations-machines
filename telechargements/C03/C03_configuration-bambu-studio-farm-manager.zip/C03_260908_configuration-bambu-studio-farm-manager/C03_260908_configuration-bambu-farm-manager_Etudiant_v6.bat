@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Bambu Farm Manager - Configuration de la session

rem Version 2026-09-08 r6 Bouton de validation IP. BFM Client doit deja etre installe.
rem Executer dans la session a configurer, SANS elevation administrateur.
rem Fermer BFM Client avant de lancer ce fichier. Aucun service n'est modifie.
rem Connexion automatique au compte Etudiant : aucune saisie de mot de passe.
rem r6 : distingue le bouton d accueil du bouton identique dans le formulaire.
rem Validation limitee au conteneur des champs IP/port, sans clic en arriere-plan.
rem Libelle de validation reconnu : Connect to server by IP.
rem L ouverture du formulaire par clic souris CDP reste controlee et bornee.
rem Attente du vrai formulaire IP/port, pas seulement de l envoi du clic.
rem IMPORTANT : ce fichier contient le mot de passe du compte partage.
rem Diffusion interne restreinte. Ne pas publier ce BAT dans un depot public.
rem /silent : supprime uniquement la pause finale.
rem Ne cree aucun compte et ne change aucun droit sur le serveur.
rem Aucun scan ni filtrage par plage IP. Les regles reseau restent inchangees.
rem Connexion par les formulaires natifs du client, pas par une API reconstruite.
rem Le client gere lui-meme les tickets, le mot de passe et TLS/HTTPS.
rem Aucun certificat, service, pare-feu, compte ou droit serveur n'est modifie.
rem Le script ne modifie pas directement le profil : le client l'enregistre.
rem En cas de formulaire inconnu, arret avec un diagnostic sans valeurs saisies.

set "BFM_SERVER_IP=10.1.2.106"
set "BFM_SERVER_PORT=8888"
set "BFM_USERNAME=Etudiant"
set "BFM_PASSWORD=EtuBambu2026"
set "BFM_CLIENT_EXE="
set "BFM_SILENT=0"
if /I "%~1"=="/silent" set "BFM_SILENT=1"
set "BFM_SELF=%~f0"

set "BFM_PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "BFM_PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%BFM_PS%" goto NO_POWERSHELL

rem Charge la section lisible de ce meme fichier, sans commande Base64 geante.
rem Aucune modification de la strategie d'execution PowerShell.
"%BFM_PS%" -NoLogo -NoProfile -Command "$ErrorActionPreference='Stop'; try { $t=[IO.File]::ReadAllText($env:BFM_SELF); $m='#'+'__BFM_POWERSHELL__'; $i=$t.IndexOf($m); if ($i -lt 0) { throw 'Section PowerShell absente.' }; & ([ScriptBlock]::Create($t.Substring($i+$m.Length))) } catch { Write-Host ('ERREUR : ' + $_.Exception.Message); exit 99 }"
set "BFM_RC=%ERRORLEVEL%"
set "BFM_PASSWORD="
echo.
if not "%BFM_RC%"=="0" echo ECHEC - code %BFM_RC%. Consulter le message ci-dessus.
if "%BFM_SILENT%"=="0" pause
endlocal & exit /b %BFM_RC%

:NO_POWERSHELL
echo ERREUR : Windows PowerShell est introuvable. Contacter la DRI.
if "%BFM_SILENT%"=="0" pause
endlocal & exit /b 41

#__BFM_POWERSHELL__
# Windows PowerShell 5.1. This section is loaded by the BAT above.
$ErrorActionPreference = 'Stop'
$serverIp = $env:BFM_SERVER_IP
$serverPort = [int]$env:BFM_SERVER_PORT
$userName = $env:BFM_USERNAME
$password = $env:BFM_PASSWORD
# Do not propagate a supplied password to the Electron child process.
[Environment]::SetEnvironmentVariable('BFM_PASSWORD', $null, 'Process')
$logFile = $null
$diagnosticFile = $null
$value = $null
$clientExe = $null
$clientProcessName = $null
$currentSessionId = (Get-Process -Id $PID).SessionId
$debugStarted = $false
$ws = $null
$exitCode = 1
$cdpPort = 0
$script:CdpId = 0

function Write-BfmLog([string]$Message) {
    if ($logFile) {
        try {
            Add-Content -LiteralPath $logFile -Encoding UTF8 -Value (
                '[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message)
        } catch { Write-Warning 'Ecriture du journal impossible.' }
    }
}

function Stop-Bfm([int]$Code, [string]$Message) {
    $errorObject = New-Object System.Exception($Message)
    $errorObject.Data['BFMExitCode'] = $Code
    throw $errorObject
}

function Find-BfmClient {
    if ($env:BFM_CLIENT_EXE) {
        if (Test-Path -LiteralPath $env:BFM_CLIENT_EXE -PathType Leaf) {
            return $env:BFM_CLIENT_EXE
        }
        Stop-Bfm 40 'Le chemin BFM_CLIENT_EXE indique est introuvable.'
    }
    $roots = @($env:ProgramW6432, $env:ProgramFiles, ${env:ProgramFiles(x86)})
    if ($env:LOCALAPPDATA) { $roots += Join-Path $env:LOCALAPPDATA 'Programs' }
    $roots = @($roots | Where-Object { $_ } | Select-Object -Unique)
    # Prefer the name visible in the supplied installation screenshot.
    foreach ($relative in @(
        'Bambu Farm Manager Client\Bambu Farm Manager Client.exe',
        'CyberBrick\CyberBrick.exe'
    )) {
        foreach ($base in $roots) {
            $candidate = Join-Path $base $relative
            if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
        }
    }
    Stop-Bfm 40 'Bambu Farm Manager Client.exe introuvable dans Program Files ou les programmes de cette session.'
}

function Get-BfmProcesses {
    @(Get-Process -Name $clientProcessName -ErrorAction SilentlyContinue |
        Where-Object { $_.SessionId -eq $currentSessionId -and $_.Path -eq $clientExe })
}

function Close-DebugClient {
    # Only the client of this Windows session; never the server or other sessions.
    $processes = @(Get-BfmProcesses)
    foreach ($process in $processes) {
        try { $null = $process.CloseMainWindow() } catch {}
    }
    $deadline = [DateTime]::UtcNow.AddSeconds(8)
    while (@(Get-BfmProcesses).Count -gt 0 -and [DateTime]::UtcNow -lt $deadline) {
        Start-Sleep -Milliseconds 250
    }
    foreach ($process in @(Get-BfmProcesses)) {
        try {
            if (-not $process.HasExited) { $process.Kill() }
        } catch {
            # The main process can terminate its children before this loop reaches them.
            if (-not $process.HasExited) { throw }
        }
    }
    $deadline = [DateTime]::UtcNow.AddSeconds(4)
    while (@(Get-BfmProcesses).Count -gt 0 -and [DateTime]::UtcNow -lt $deadline) {
        Start-Sleep -Milliseconds 200
    }
    if (@(Get-BfmProcesses).Count -gt 0) {
        throw 'Le client en mode configuration est encore ouvert.'
    }
}

function Get-CdpTargets {
    # Local diagnostic request only, without the institutional HTTP proxy.
    $request = [System.Net.WebRequest]::Create(('http://127.0.0.1:{0}/json/list' -f $cdpPort))
    $request.Proxy = $null
    $request.Timeout = 1500
    $request.ReadWriteTimeout = 1500
    $reply = $null
    $reader = $null
    try {
        $reply = $request.GetResponse()
        $reader = New-Object System.IO.StreamReader($reply.GetResponseStream())
        return ($reader.ReadToEnd() | ConvertFrom-Json)
    } finally {
        if ($reader) { $reader.Dispose() }
        if ($reply) { $reply.Dispose() }
    }
}

function Confirm-CdpListener {
    # Fail closed if the debug port is exposed on the LAN or belongs to another app.
    $listeners = @(Get-NetTCPConnection -LocalPort $cdpPort -State Listen -ErrorAction Stop)
    if ($listeners.Count -eq 0) { throw 'Port local de configuration absent.' }
    foreach ($entry in $listeners) {
        $address = [System.Net.IPAddress]::Parse($entry.LocalAddress)
        if (-not [System.Net.IPAddress]::IsLoopback($address)) {
            throw 'Le port de configuration ne doit pas etre expose au reseau.'
        }
        $owner = Get-Process -Id $entry.OwningProcess -ErrorAction Stop
        if ($owner.SessionId -ne $currentSessionId -or $owner.ProcessName -ne $clientProcessName) {
            throw 'Le port de configuration appartient a un autre processus.'
        }
        if ($owner.Path -ne $clientExe) {
            throw 'Le processus du port de configuration ne correspond pas au client detecte.'
        }
    }
}

function Invoke-Cdp {
    param([string]$Method, [hashtable]$Params = @{}, [int]$TimeoutSeconds = 75)
    $script:CdpId++
    $id = $script:CdpId
    $payload = @{id=$id; method=$Method; params=$Params} | ConvertTo-Json -Compress -Depth 30
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($payload)
    $segment = New-Object System.ArraySegment[byte] -ArgumentList @(,$bytes)
    $cancel = New-Object System.Threading.CancellationTokenSource
    $cancel.CancelAfter($TimeoutSeconds * 1000)
    try {
        $null = $ws.SendAsync($segment,
            [System.Net.WebSockets.WebSocketMessageType]::Text,
            $true, $cancel.Token).GetAwaiter().GetResult()
        while ($true) {
            $stream = New-Object System.IO.MemoryStream
            try {
                do {
                    $buffer = New-Object byte[] 32768
                    $chunk = New-Object System.ArraySegment[byte] -ArgumentList @(,$buffer)
                    $received = $ws.ReceiveAsync($chunk, $cancel.Token).GetAwaiter().GetResult()
                    if ($received.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Close) {
                        throw 'Connexion locale de configuration fermee.'
                    }
                    $stream.Write($buffer, 0, $received.Count)
                    if ($stream.Length -gt 2097152) { throw 'Reponse locale trop volumineuse.' }
                } until ($received.EndOfMessage)
                $message = [System.Text.Encoding]::UTF8.GetString($stream.ToArray()) | ConvertFrom-Json
            } finally { $stream.Dispose() }
            if ($message.id -eq $id) {
                if ($message.error) { throw 'Requete de configuration refusee par le client.' }
                return $message
            }
        }
    } finally { $cancel.Dispose() }
}

function Open-BfmServerForm {
    # Only the opening control is clicked here. IP/login submissions stay in the
    # existing native form routine. No network, certificate or password change.
    $openingProbe = @'
(() => {
    // Read-only probe. It never supplies credentials or submits a form.
    const normalize = value => String(value || '').normalize('NFD')
        .replace(/[\u0300-\u036f\u200b-\u200f\ufeff]/g, '')
        .toLowerCase().replace(/[^a-z0-9]/g, '');
    const allowedLabels = new Set([
        'connecttoserverbyip', 'connectbyip', 'connecttoserverbyipaddress',
        'connexionauserveurparip', 'seconnecterauserveurparip',
        'connecterauserveurparip', 'connexionparip', 'connecterparip',
        'seconnecterauserveurparadresseip', 'connexionauserveurparadresseip'
    ]);
    const controls = 'button,[role="button"],a,input[type="button"],input[type="submit"],.el-button,.ant-btn,.n-button,.v-btn';
    const visible = element => {
        if (!element || !element.isConnected || !element.getClientRects().length) return false;
        for (let item = element; item; item = item.parentElement) {
            const style = getComputedStyle(item);
            if (item.hidden || style.display === 'none' || style.visibility === 'hidden' ||
                style.visibility === 'collapse' || Number(style.opacity) === 0) return false;
        }
        return true;
    };
    const enabled = element => !element.disabled &&
        !element.closest('[inert],button:disabled,[aria-disabled="true"],.is-disabled,.disabled');
    const labels = element => {
        const copy = element.cloneNode(true);
        copy.querySelectorAll('svg,[aria-hidden="true"],[hidden],style,script').forEach(item => item.remove());
        return [element.getAttribute('aria-label'), element.getAttribute('title'),
            element.tagName === 'INPUT' ? element.value : '',
            element.innerText, copy.textContent].map(normalize).filter(Boolean);
    };
    const fieldName = element => {
        const group = element.closest('.el-form-item,.ant-form-item,.n-form-item,.form-group');
        const label = group && group.querySelector('label,.el-form-item__label,.n-form-item-label');
        return [element.name, element.id, element.placeholder, element.getAttribute('aria-label'),
            ...Array.from(element.labels || []).map(item => item.textContent), label && label.textContent]
            .join(' ').replace(/([a-z])([A-Z])/g, '$1 $2').replace(/[_-]/g, ' ')
            .normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    };
    if (!['file:', 'app:'].includes(location.protocol)) return {status:'origin_not_local'};
    const inputs = Array.from(document.querySelectorAll('input,select')).filter(element =>
        visible(element) && !['hidden','checkbox','radio','button','submit','reset','file'].includes(element.type));
    const ips = inputs.filter(element => /\b(ip|ipv4|hostname|host|adresse|address)\b/.test(fieldName(element)) &&
        !/email|courriel|password|mot de passe/.test(fieldName(element)));
    const ports = inputs.filter(element => /\bport\b/.test(fieldName(element)));
    if (ips.length === 1 && ports.length === 1) return {status:'form_ready'};
    if (inputs.some(element => element.type === 'password')) return {status:'login_form_present'};
    // Leave all profile/account checks to the original, guarded login routine.
    let activeProfile = false;
    try {
        const app = JSON.parse(localStorage.getItem('app') || '{}');
        activeProfile = Array.isArray(app.servers) && app.servers.some(item => item && item.active === true);
    } catch (_) {}
    const matches = new Set();
    for (const element of document.querySelectorAll(controls + ',span,div,label,p')) {
        if (!visible(element) || !labels(element).some(text => allowedLabels.has(text))) continue;
        const owner = element.closest(controls);
        // Do not treat a container around a disabled/covered button as another action.
        if (!owner && element.querySelector(controls)) continue;
        const target = owner || element;
        if (visible(target) && enabled(target)) matches.add(target);
    }
    // Several nested text nodes inside the same control are a single action.
    const targets = Array.from(matches).filter(element =>
        !Array.from(matches).some(other => other !== element && element.contains(other)));
    if (targets.length > 1) return {status:'ambiguous', candidates:targets.length};
    const dialogs = Array.from(document.querySelectorAll('[role="dialog"],.el-dialog,.ant-modal,.n-dialog'));
    if (dialogs.some(visible) && (targets.length === 0 || !dialogs.some(dialog =>
        visible(dialog) && dialog.contains(targets[0])))) return {status:'modal_pending'};
    if (!targets.length) return {status:activeProfile ? 'existing_profile' : 'waiting_for_button'};
    const target = targets[0];
    target.scrollIntoView({block:'center', inline:'nearest', behavior:'instant'});
    const bounds = target.getBoundingClientRect();
    const left = Math.max(0, bounds.left), right = Math.min(innerWidth, bounds.right);
    const top = Math.max(0, bounds.top), bottom = Math.min(innerHeight, bounds.bottom);
    if (right <= left || bottom <= top) return {status:'out_of_view'};
    const x = (left + right) / 2, y = (top + bottom) / 2;
    const hit = document.elementFromPoint(x, y);
    if (!hit || !(hit === target || target.contains(hit))) return {status:'button_covered'};
    if (getComputedStyle(target).pointerEvents === 'none') return {status:'button_covered'};
    return {status:'click_target', x:x, y:y};
})()
'@
    Write-Host 'Ouverture automatique : Connect to server by IP...'
    try { $null = Invoke-Cdp -Method 'Page.bringToFront' -TimeoutSeconds 5 } catch {}
    $deadline = [DateTime]::UtcNow.AddSeconds(35)
    $lastClick = [DateTime]::MinValue
    $attempts = 0
    $lastStatus = 'waiting_for_button'
    $previousPoint = $null
    $stableSince = [DateTime]::UtcNow
    while ([DateTime]::UtcNow -lt $deadline) {
        $reply = Invoke-Cdp -Method 'Runtime.evaluate' -TimeoutSeconds 5 -Params @{
            expression=$openingProbe; returnByValue=$true
        }
        if ($reply.result.exceptionDetails -or -not $reply.result.result.value) {
            Stop-Bfm 48 'Lecture de l accueil BFM impossible. Aucun identifiant transmis.'
        }
        $probe = $reply.result.result.value
        $lastStatus = [string]$probe.status
        if (@('form_ready','login_form_present','existing_profile') -contains $lastStatus) {
            Write-BfmLog ('Ouverture automatique : etat={0}; clics={1}.' -f $lastStatus, $attempts)
            if ($lastStatus -eq 'form_ready') {
                Write-Host 'Formulaire IP/port detecte. Poursuite sans clic manuel.'
            }
            return
        }
        if ($lastStatus -eq 'origin_not_local') {
            Stop-Bfm 48 'La page du client n est pas locale. Aucun clic ni identifiant transmis.'
        }
        if ($lastStatus -eq 'ambiguous') {
            Stop-Bfm 48 'Plusieurs boutons de connexion par IP detectes. Aucun clic effectue.'
        }
        if ($lastStatus -eq 'click_target') {
            if ($null -eq $probe.x -or $null -eq $probe.y) { Stop-Bfm 48 'Position du bouton non determinee.' }
            $x = [double]$probe.x
            $y = [double]$probe.y
            if ([double]::IsNaN($x) -or [double]::IsNaN($y) -or
                [double]::IsInfinity($x) -or [double]::IsInfinity($y) -or $x -lt 0 -or $y -lt 0) {
                Stop-Bfm 48 'Position du bouton invalide. Aucun clic effectue.'
            }
            $now = [DateTime]::UtcNow
            if ($null -eq $previousPoint -or [Math]::Abs($previousPoint.x - $x) -gt 1 -or
                [Math]::Abs($previousPoint.y - $y) -gt 1) {
                $previousPoint = @{x=$x; y=$y}
                $stableSince = $now
            } elseif (($now - $stableSince).TotalMilliseconds -ge 350 -and
                ($now - $lastClick).TotalMilliseconds -ge 2000 -and $attempts -lt 3) {
                # CDP coordinates are measured in the client viewport, not fixed
                # screen positions. A fresh probe guards against hover/overlay changes.
                $null = Invoke-Cdp -Method 'Input.dispatchMouseEvent' -TimeoutSeconds 5 -Params @{
                    type='mouseMoved'; x=$x; y=$y
                }
                $check = Invoke-Cdp -Method 'Runtime.evaluate' -TimeoutSeconds 5 -Params @{
                    expression=$openingProbe; returnByValue=$true
                }
                $fresh = $check.result.result.value
                if (-not $check.result.exceptionDetails -and $fresh -and $fresh.status -eq 'click_target' -and
                    $null -ne $fresh.x -and $null -ne $fresh.y -and
                    [Math]::Abs([double]$fresh.x - $x) -le 1 -and [Math]::Abs([double]$fresh.y - $y) -le 1) {
                    try {
                        $null = Invoke-Cdp -Method 'Input.dispatchMouseEvent' -TimeoutSeconds 5 -Params @{
                            type='mousePressed'; x=$x; y=$y; button='left'; buttons=1; clickCount=1
                        }
                    } finally {
                        $null = Invoke-Cdp -Method 'Input.dispatchMouseEvent' -TimeoutSeconds 5 -Params @{
                            type='mouseReleased'; x=$x; y=$y; button='left'; buttons=0; clickCount=1
                        }
                    }
                    $attempts++
                    $lastClick = [DateTime]::UtcNow
                    Write-Host ('Clic automatique sur Connect to server by IP ({0}/3).' -f $attempts)
                    Write-BfmLog ('Clic d ouverture IP effectue; tentative={0}. Attente du formulaire.' -f $attempts)
                    # A sent click is NOT proof that the form has opened.
                    $previousPoint = $null
                }
            }
        } else {
            $previousPoint = $null
        }
        Start-Sleep -Milliseconds 250
    }
    # No labels, input values, HTML, cookies or credentials in this diagnostic.
    try {
        @{stage='ouverture_formulaire_serveur'; reason=$lastStatus; openingClicks=$attempts} |
            ConvertTo-Json | Set-Content -LiteralPath $diagnosticFile -Encoding UTF8
        Write-Host ('Diagnostic de l interface : {0}' -f $diagnosticFile)
    } catch {}
    Stop-Bfm 48 ('Formulaire IP/port non confirme apres attente. Etat={0}; clics={1}. Aucun mot de passe soumis.' -f
        $lastStatus, $attempts)
}

try {
    if ($env:OS -ne 'Windows_NT' -or $PSVersionTable.PSVersion -lt [version]'5.1') {
        Stop-Bfm 41 'Windows PowerShell 5.1 ou plus recent est requis.'
    }
    $identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object System.Security.Principal.WindowsPrincipal($identity)
    if ($principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)) {
        Stop-Bfm 42 'Relancer ce BAT par double-clic normal, sans Executer en tant qu administrateur.'
    }
    $logDir = Join-Path $env:LOCALAPPDATA 'BambuFarmManagerDeploy'
    $null = New-Item -ItemType Directory -Path $logDir -Force
    $logFile = Join-Path $logDir 'deploy-native-v6.log'
    $diagnosticFile = Join-Path $logDir 'diagnostic-interface-v6.json'
    Write-BfmLog 'Debut de la configuration, version du script 2026-09-08 r6 Bouton de validation IP.'
    $clientExe = [System.IO.Path]::GetFullPath((Find-BfmClient))
    $clientProcessName = [System.IO.Path]::GetFileNameWithoutExtension($clientExe)
    $version = (Get-Item -LiteralPath $clientExe).VersionInfo.ProductVersion
    Write-Host ''
    Write-Host '==============================================================='
    Write-Host ' Bambu Farm Manager - configuration de la session'
    Write-Host '==============================================================='
    Write-Host ('Utilisateur Windows : {0}\{1}' -f $env:USERDOMAIN, $env:USERNAME)
    Write-Host ('Serveur             : {0}:{1}' -f $serverIp, $serverPort)
    Write-Host ('Compte BFM          : {0}' -f $userName)
    Write-Host ('Client              : {0}' -f $clientExe)
    Write-Host ('Version du client   : {0}' -f $version)
    Write-Host 'Version du script   : 2026-09-08 r6 Bouton de validation IP'
    Write-Host ''
    Write-BfmLog ('Client={0}; version={1}; session={2}; serveur={3}:{4}' -f
        $clientExe, $version, $currentSessionId, $serverIp, $serverPort)

    if (@(Get-BfmProcesses).Count -gt 0) {
        Stop-Bfm 43 'Fermer Bambu Farm Manager Client, y compris son icone de notification, puis relancer ce BAT.'
    }
    if ($serverPort -lt 1 -or $serverPort -gt 65535) { Stop-Bfm 31 'Port serveur invalide.' }
    Write-Host 'Verification de la connexion au serveur...'
    $tcp = New-Object System.Net.Sockets.TcpClient
    try {
        $attempt = $tcp.BeginConnect($serverIp, $serverPort, $null, $null)
        if (-not $attempt.AsyncWaitHandle.WaitOne(4000, $false)) { throw 'timeout' }
        $tcp.EndConnect($attempt)
    } catch {
        Stop-Bfm 31 ('Serveur inaccessible sur {0}:{1}. Verifier le reseau et le serveur avec la DRI.' -f $serverIp, $serverPort)
    } finally { $tcp.Close() }
    Write-BfmLog 'Connexion TCP au serveur reussie. Authentification non encore verifiee.'

    if ([string]::IsNullOrEmpty($password)) {
        Stop-Bfm 44 'Mot de passe de deploiement absent dans le BAT. Aucune saisie interactive.'
    }
    Write-Host 'Connexion automatique au compte Etudiant, sans saisie de mot de passe.'
    Write-Host 'Methode : formulaires natifs du client. HTTPS/TLS gere par BFM.'
    Write-Host 'Ne pas utiliser la fenetre du client pendant la configuration.'

    # Allocate a different loopback port for each configuration run.
    $listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 0)
    try {
        $listener.Start()
        $cdpPort = ([System.Net.IPEndPoint]$listener.LocalEndpoint).Port
    } finally { $listener.Stop() }
    Write-Host 'Ouverture du client pour configurer le profil...'
    $launch = Start-Process -FilePath $clientExe -WorkingDirectory (Split-Path -Parent $clientExe) -ArgumentList @(
        '--remote-debugging-address=127.0.0.1', ('--remote-debugging-port={0}' -f $cdpPort)
    ) -PassThru
    $debugStarted = $true
    Write-BfmLog ('Client de configuration lance, port local={0}.' -f $cdpPort)

    $page = $null
    $deadline = [DateTime]::UtcNow.AddSeconds(35)
    do {
        $targets = @()
        try { $targets = @(Get-CdpTargets) } catch {}
        $pages = @($targets | Where-Object {
            $_.type -eq 'page' -and $_.webSocketDebuggerUrl -and
            $_.url -and $_.url -ne 'about:blank' -and
            $_.url -notlike 'devtools:*' -and $_.url -notlike 'chrome-devtools:*'
        })
        if ($pages.Count -eq 1) { $page = $pages[0]; break }
        if ($pages.Count -gt 1) { Stop-Bfm 33 'Plusieurs pages du client sont ouvertes. Fermer les fenetres supplementaires et reessayer.' }
        Start-Sleep -Milliseconds 400
    } while ([DateTime]::UtcNow -lt $deadline)
    if (-not $page) { Stop-Bfm 32 'Interface locale de configuration introuvable. Verifier la version du client et les restrictions DRI.' }
    try { Confirm-CdpListener } catch {
        Stop-Bfm 34 ('Verification du port local impossible : {0}' -f $_.Exception.Message)
    }
    $socketUri = [Uri]$page.webSocketDebuggerUrl
    if ($socketUri.Scheme -ne 'ws' -or -not $socketUri.IsLoopback -or $socketUri.Port -ne $cdpPort) {
        Stop-Bfm 34 'Adresse de configuration locale inattendue. Aucune authentification envoyee.'
    }
    $ws = New-Object System.Net.WebSockets.ClientWebSocket
    $ws.Options.Proxy = $null
    $connectCancel = New-Object System.Threading.CancellationTokenSource
    $connectCancel.CancelAfter(10000)
    try {
        $null = $ws.ConnectAsync($socketUri, $connectCancel.Token).GetAwaiter().GetResult()
    } finally { $connectCancel.Dispose() }

    Open-BfmServerForm

    $ipJson = $serverIp | ConvertTo-Json -Compress
    $portJson = ([string]$serverPort) | ConvertTo-Json -Compress
    $userJson = $userName | ConvertTo-Json -Compress
    $passJson = $password | ConvertTo-Json -Compress
    # The local CDP connection below is not the TLS connection to the farm server.
    # Never disable TLS verification, change the client's proxy, or forge login API calls.
    $javascript = @"
(async () => {
    const ip = $ipJson;
    const port = $portJson;
    const userName = $userJson;
    const password = $passJson;
    const timeoutMs = 90000;
    const started = Date.now();
    const actions = [];
    let stage = 'accueil';
    let serverSubmitted = false;
    let loginSubmitted = false;
    let formFilled = '';
    let changes = 0;
    let lastButtonSelection = null;
    let lastActionAt = started;
    const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
    const normalize = value => String(value || '').normalize('NFD')
        .replace(/[\u0300-\u036f\u200b-\u200f\ufeff]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
    const safe = value => String(value || '').split(password).join('[MASQUE]')
        .replace(/eyJ[A-Za-z0-9_+\/=-]{10,}(?:\.[A-Za-z0-9_+\/=-]+){0,2}/g, '[JETON MASQUE]')
        .replace(/[A-Za-z0-9_+\/=-]{100,}/g, '[VALEUR LONGUE MASQUEE]').slice(0, 140);
    const visible = element => {
        if (!element || !element.isConnected || !element.getClientRects().length) return false;
        for (let item = element; item; item = item.parentElement) {
            const style = getComputedStyle(item);
            if (item.hidden || style.display === 'none' || style.visibility === 'hidden' ||
                style.visibility === 'collapse' || Number(style.opacity) === 0) return false;
        }
        return true;
    };
    const fields = root => Array.from(root.querySelectorAll('input,select')).filter(element =>
        visible(element) && !['hidden','checkbox','radio','submit','button','reset','file'].includes(element.type));
    const description = element => {
        const label = Array.from(element.labels || []).map(item => item.textContent).join(' ');
        const group = element.closest('.el-form-item,.ant-form-item,.n-form-item,.form-group');
        const groupLabel = group && group.querySelector('label,.el-form-item__label,.n-form-item-label');
        const names = [element.name, element.id].map(value => String(value || '')
            .replace(/([a-z])([A-Z])/g, (match, a, b) => a + ' ' + b).replace(/[_-]/g, ' ')).join(' ');
        return normalize([names, element.getAttribute('placeholder'),
            element.getAttribute('aria-label'), label, groupLabel && groupLabel.textContent].join(' '));
    };
    const isIp = element => /\b(ip|ipv4|hostname|host|adresse|address)\b/.test(description(element)) &&
        !/\b(email|mail|courriel|password)\b/.test(description(element));
    const isPort = element => /\bport\b/.test(description(element));
    const isUser = element => /user.?name|username|utilisateur|identifiant|\baccount\b|\bcompte\b/.test(description(element)) &&
        !/password|mot de passe|email|courriel/.test(description(element)) && element.type !== 'password';
    const isPass = element => element.type === 'password';
    const dialogSelector = 'dialog,[role="dialog"],[aria-modal="true"],.el-dialog,.ant-modal,.n-dialog,.n-card,.v-dialog,.modal-content';
    const controlSelector = 'button,[role="button"],a,input[type="submit"],input[type="button"],.el-button,.ant-btn,.n-button,.v-btn';
    const scopeOf = element => element.closest(dialogSelector) || element.closest('form') || document.body;
    const enabled = element => !element.disabled && element.getAttribute('aria-disabled') !== 'true' &&
        !element.closest('[inert],button:disabled,[aria-disabled="true"],.is-disabled,.disabled');
    const clickables = root => Array.from(root.querySelectorAll(controlSelector + ',span,div'))
        .filter(element => visible(element) && enabled(element));
    const actionLabels = element => {
        const copy = element.cloneNode(true);
        copy.querySelectorAll('svg,[aria-hidden="true"],[hidden],style,script').forEach(item => item.remove());
        return [element.getAttribute('aria-label'), element.getAttribute('title'),
            element.tagName === 'INPUT' ? element.value : '', element.innerText, copy.textContent]
            .map(normalize).filter(Boolean);
    };
    const receivesPointer = element => {
        // A visible background button is not actionable through a modal overlay.
        if (!visible(element) || getComputedStyle(element).pointerEvents === 'none') return false;
        const bounds = element.getBoundingClientRect();
        const left = Math.max(0, bounds.left), right = Math.min(innerWidth, bounds.right);
        const top = Math.max(0, bounds.top), bottom = Math.min(innerHeight, bounds.bottom);
        if (right <= left || bottom <= top) return false;
        const hit = document.elementFromPoint((left + right) / 2, (top + bottom) / 2);
        return Boolean(hit && (hit === element || element.contains(hit)));
    };
    const actionMatches = (root, pattern, requireActionable = true) => {
        const matches = new Set();
        for (const element of root.querySelectorAll(controlSelector + ',span,div')) {
            if (!visible(element) || !actionLabels(element).some(text => pattern.test(text))) continue;
            const owner = element.closest(controlSelector);
            if (owner && !root.contains(owner)) continue;
            if (!owner && element.querySelector(controlSelector)) continue;
            const target = owner || element;
            if (!visible(target)) continue;
            if (requireActionable && (!enabled(target) || !receivesPointer(target))) continue;
            matches.add(target);
        }
        // A nested label and its button represent exactly one action.
        const found = Array.from(matches);
        return found.filter(element => !found.some(other => other !== element && element.contains(other)));
    };
    const byIpPattern = /^(connect to server by ip(?: address)?|connect by ip|connexion au serveur par ip|se connecter au serveur par ip|connecter au serveur par ip|connexion par ip|connecter par ip)$/;
    // r6: the same caption is used both on the welcome page AND in the modal.
    const connectPattern = /^(connect to server by ip(?: address)?|connect by ip|connexion au serveur par ip|se connecter au serveur par ip|connecter au serveur par ip|connexion par ip|connecter par ip|connect|connect to server|connexion|se connecter|connecter|confirm|confirmer|ok|add|ajouter)$/;
    const loginPattern = /^(log in|login|sign in|connexion|se connecter|connecter)$/;
    const serverScope = (ipField, portField) => {
        // Prefer an explicit dialog containing BOTH fields. Never search the
        // whole page to submit the IP form: its background has the same button.
        const modal = ipField.closest(dialogSelector);
        if (modal) return visible(modal) && modal.contains(portField) ? modal : null;
        // Some clients use an unlabelled custom modal. Find the smallest shared
        // container with both fields AND a recognized action, without using body.
        for (let root = ipField.parentElement; root && root !== document.body && root !== document.documentElement;
             root = root.parentElement) {
            if (!root.contains(portField)) continue;
            if (actionMatches(root, connectPattern, false).length) return root;
        }
        return null;
    };
    const nativeErrors = () => Array.from(document.querySelectorAll(
        '.el-message--error,.el-notification.error,.ant-message-error,.ant-notification-notice-error,.n-message--error,.el-form-item__error,.ant-form-item-explain-error,[role="alert"]'))
        .filter(visible).map(element => safe(element.textContent)).filter(Boolean).slice(0, 3);
    const profile = () => {
        let app;
        try { app = JSON.parse(localStorage.getItem('app') || '{}'); }
        catch (_) { return {state:'illisible'}; }
        if (!app || typeof app !== 'object' || (app.servers !== undefined && !Array.isArray(app.servers)))
            return {state:'format_inconnu'};
        const servers = app.servers || [];
        const active = servers.filter(item => item && item.active === true);
        if (active.length > 1) return {state:'plusieurs_serveurs_actifs'};
        if (!active.length) return {state:'absent'};
        const server = active[0];
        if (server.ip !== ip || String(server.port) !== String(port)) return {state:'autre_serveur'};
        if (server.user_name && server.user_name !== userName && server.token) return {state:'autre_compte'};
        if (!server.token || typeof server.token !== 'string') return {state:'cible_sans_connexion'};
        if (server.user_name !== userName) return {state:'compte_non_confirme'};
        if (typeof server.role !== 'string' || !server.role.trim()) return {state:'role_non_confirme'};
        if (/admin|owner|proprietaire/i.test(server.role)) return {state:'role_administrateur'};
        return {state:'cible_connectee', userName:userName, ip:ip, port:String(port), role:safe(server.role)};
    };
    const snapshot = () => ({
        stage:stage, actions:actions.slice(), elapsedSeconds:Math.round((Date.now()-started)/1000),
        fields:fields(document).slice(0, 16).map(element => ({
            type:element.type || element.tagName.toLowerCase(), label:safe(description(element)),
            disabled:Boolean(element.disabled), readOnly:Boolean(element.readOnly)
        })),
        buttons:clickables(document).filter(element => element.matches('button,[role="button"],a,input[type="submit"]'))
            .map(element => safe(element.tagName === 'INPUT' ? element.value : element.textContent))
            .filter(value => value && value.length <= 140).slice(0, 24),
        messages:nativeErrors(), profileState:profile().state,
        buttonSelection:lastButtonSelection
        // No input values, cookie, ticket, password, token or HTML dump.
    });
    const fail = reason => ({ok:false, stage:stage, reason:reason, diagnostic:snapshot()});
    const fill = (element, value) => {
        if (!visible(element)) throw new Error('champ_disparu');
        if (element.value === value) return;
        if (!enabled(element) || element.readOnly) throw new Error('champ_verrouille');
        if (element.tagName === 'SELECT') {
            const option = Array.from(element.options).filter(item => item.value === value || item.textContent.trim() === value);
            if (option.length !== 1) throw new Error('option_utilisateur_introuvable');
            element.value = option[0].value;
        } else {
            const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
            element.focus();
            setter.call(element, value);
        }
        element.dispatchEvent(new Event('input', {bubbles:true}));
        element.dispatchEvent(new Event('change', {bubbles:true}));
        element.blur();
    };
    const valueMatches = (element, expected) => element.tagName === 'SELECT'
        ? Array.from(element.selectedOptions).some(option => option.value === expected || option.textContent.trim() === expected)
        : element.value === expected;
    const unique = (list, predicate) => {
        const matches = list.filter(predicate);
        return matches.length === 1 ? matches[0] : null;
    };
    const submit = (root, pattern) => {
        const buttons = actionMatches(root, pattern);
        lastButtonSelection = {
            stage:stage, candidates:buttons.length,
            scopedToContainer:root !== document.body && root !== document,
            labels:buttons.slice(0, 4).map(element => safe(actionLabels(element)[0]))
        };
        if (buttons.length !== 1) return false;
        // Only the unique, enabled, uncovered action INSIDE this form is clicked.
        // No discovery, activation, registration, reset, printing or repeated login.
        const button = buttons[0];
        if (!root.contains(button) || !enabled(button) || !receivesPointer(button)) return false;
        button.click();
        lastActionAt = Date.now();
        return true;
    };
    try {
        // Never send the local account password to a remotely hosted/cloud page.
        if (location.protocol !== 'file:' && location.protocol !== 'app:') return fail('origine_client_non_locale');
        const baseline = profile();
        if (['autre_serveur','autre_compte','role_administrateur','plusieurs_serveurs_actifs',
             'illisible','format_inconnu'].includes(baseline.state)) return fail(baseline.state);
        let targetSelected = ['cible_sans_connexion','cible_connectee','compte_non_confirme','role_non_confirme'].includes(baseline.state);
        while (Date.now() - started < timeoutMs) {
            const all = fields(document);
            const passwordFields = all.filter(isPass);
            const current = profile();
            if (['role_administrateur','autre_compte','autre_serveur','plusieurs_serveurs_actifs'].includes(current.state))
                return fail(current.state);
            const welcomeButtons = actionMatches(document, byIpPattern);
            if (current.state === 'cible_connectee' && passwordFields.length === 0 && welcomeButtons.length === 0) {
                return {ok:true, stage:'profil_enregistre_par_client', ...current,
                    freshLogin:loginSubmitted, diagnostic:{actions:actions.slice()}};
            }
            if ((loginSubmitted || serverSubmitted) && Date.now() - lastActionAt > 800 && nativeErrors().length)
                return fail('message_erreur_du_client');
            if (loginSubmitted) {
                stage = 'attente_connexion_etudiant';
                await pause(250); continue;
            }
            // IP and port are explicitly identified; never replace them with guessed defaults.
            const ipField = unique(all, isIp);
            const portField = unique(all, isPort);
            if (!serverSubmitted && ipField && portField) {
                stage = 'formulaire_serveur';
                if (!ipField || !portField) {
                    if (Date.now() - lastActionAt > 5000) return fail('champs_ip_port_non_reconnus');
                    await pause(250); continue;
                }
                const root = serverScope(ipField, portField);
                if (!root) {
                    if (Date.now() - lastActionAt > 6000) return fail('conteneur_formulaire_serveur_non_reconnu');
                    await pause(250); continue;
                }
                if (!root.contains(portField)) return fail('formulaire_serveur_ambigu');
                const local = fields(root);
                const passField = unique(local, isPass);
                const userField = unique(local, isUser);
                if (passField && (!userField || /email|courriel/.test(description(userField))))
                    return fail('formulaire_compte_local_non_reconnu');
                const ready = valueMatches(ipField, ip) && valueMatches(portField, String(port)) &&
                    (!passField || (valueMatches(userField, userName) && valueMatches(passField, password)));
                if (!ready || formFilled !== 'serveur') {
                    if (++changes > 5) return fail('champs_non_stables');
                    fill(ipField, ip); fill(portField, String(port));
                    if (passField) { fill(userField, userName); fill(passField, password); }
                    formFilled = 'serveur';
                    await pause(250); continue;
                }
                if (!submit(root, connectPattern)) {
                    if (Date.now() - lastActionAt > 6000) return fail('bouton_connexion_serveur_non_reconnu');
                    await pause(250); continue;
                }
                actions.push('adresse_et_port_transmis_au_client');
                serverSubmitted = true;
                targetSelected = true;
                if (passField) { loginSubmitted = true; actions.push('connexion_etudiant_soumise_une_fois'); }
                stage = 'attente_formulaire_connexion';
                await pause(500); continue;
            }
            if (passwordFields.length) {
                stage = 'formulaire_connexion';
                if (!targetSelected) return fail('serveur_cible_non_confirme');
                if (passwordFields.length !== 1) return fail('plusieurs_champs_mot_de_passe');
                const passField = passwordFields[0];
                const root = scopeOf(passField);
                const userField = unique(fields(root), isUser);
                if (!userField || userField.type === 'email' || /email|courriel/.test(description(userField)))
                    return fail('champ_utilisateur_local_non_reconnu');
                const ready = valueMatches(userField, userName) && valueMatches(passField, password);
                if (!ready || formFilled !== 'connexion') {
                    if (++changes > 5) return fail('champs_non_stables');
                    fill(userField, userName); fill(passField, password);
                    formFilled = 'connexion';
                    await pause(250); continue;
                }
                if (!submit(root, loginPattern)) {
                    if (Date.now() - lastActionAt > 6000) return fail('bouton_connexion_compte_non_reconnu');
                    await pause(250); continue;
                }
                loginSubmitted = true;
                actions.push('connexion_etudiant_soumise_une_fois');
                stage = 'attente_connexion_etudiant';
                await pause(500); continue;
            }
            if (!serverSubmitted) {
                if (welcomeButtons.length > 1) return fail('plusieurs_boutons_connexion_ip');
                if (welcomeButtons.length === 1) {
                    // The CDP opening step already ran. Never fall back to an
                    // unverified synthetic click or resubmit account credentials.
                    return fail('formulaire_ip_non_maintenu_apres_ouverture');
                }
                if (Date.now() - started > 10000) return fail('ecran_accueil_non_reconnu');
            }
            await pause(250);
        }
        return fail('delai_interface_depasse');
    } catch (error) {
        const known = ['champ_disparu','champ_verrouille','option_utilisateur_introuvable'];
        return fail(known.includes(error.message) ? error.message : 'erreur_automatisation_interface');
    }
})()
"@
    Write-Host 'Remplissage automatique des formulaires BFM...'
    Write-Host 'Validation : bouton Connect to server by IP DANS le formulaire IP/port.'
    try {
        $response = Invoke-Cdp -Method 'Runtime.evaluate' -TimeoutSeconds 110 -Params @{
            expression=$javascript; awaitPromise=$true; returnByValue=$true
        }
    } catch {
        Stop-Bfm 35 'La connexion locale au client a ete interrompue ou a depasse le delai. Aucune nouvelle tentative de mot de passe.'
    } finally {
        $password = $null
        $passJson = $null
        $javascript = $null
    }
    if ($response.result.exceptionDetails) {
        Stop-Bfm 35 'Le client a refuse le pilotage de son interface. Compatibilite de version a verifier.'
    }
    $value = $response.result.result.value
    if (-not $value -or -not $value.ok) {
        $stage = if ($value -and $value.stage) { [string]$value.stage } else { 'inconnue' }
        $reason = if ($value -and $value.reason) { [string]$value.reason } else { 'non_precise' }
        if ($value -and $value.diagnostic) {
            try {
                $value.diagnostic | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $diagnosticFile -Encoding UTF8
                Write-Host ('Diagnostic de l interface : {0}' -f $diagnosticFile)
            } catch { Write-Warning 'Enregistrement du diagnostic impossible.' }
        }
        Stop-Bfm 46 ('Connexion non confirmee. Etape={0}; diagnostic={1}. Ne pas modifier le pare-feu ni les certificats.' -f $stage, $reason)
    }
    if ($value.userName -ne $userName -or $value.ip -ne $serverIp -or [string]$value.port -ne [string]$serverPort) {
        Stop-Bfm 47 'Le profil enregistre ne correspond pas au compte et au serveur demandes.'
    }
    Write-BfmLog ('Profil enregistre par le client; serveur={0}:{1}; compte={2}; role={3}; nouvelle_connexion={4}.' -f
        $value.ip, $value.port, $value.userName, $value.role, $value.freshLogin)
    # The client, not this script, owns all profile writes.
    Start-Sleep -Milliseconds 1800
    $exitCode = 0
} catch {
    $exitCode = 99
    if ($_.Exception.Data.Contains('BFMExitCode')) { $exitCode = [int]$_.Exception.Data['BFMExitCode'] }
    $errorText = $_.Exception.Message
    Write-Host ''
    Write-Host ('ERREUR {0} : {1}' -f $exitCode, $errorText) -ForegroundColor Red
    Write-BfmLog ('ERREUR {0} : {1}' -f $exitCode, $errorText)
} finally {
    $password = $null
    $passJson = $null
    $javascript = $null
    if ($ws) { try { $ws.Abort(); $ws.Dispose() } catch {} }
    if ($debugStarted) {
        try {
            Close-DebugClient
            $remaining = @([System.Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners() |
                Where-Object { $_.Port -eq $cdpPort })
            if ($remaining.Count -gt 0) { throw 'Le port local de configuration est toujours ouvert.' }
            Write-BfmLog 'Client de configuration ferme; port local ferme.'
            $null = Start-Process -FilePath $clientExe -WorkingDirectory (Split-Path -Parent $clientExe) -PassThru
            Write-BfmLog 'Client relance normalement, sans option de debogage.'
        } catch {
            $exitCode = 37
            Write-Host 'ERREUR 37 : fermeture ou relance du client impossible. Fermer le client et aviser la DRI.' -ForegroundColor Red
            Write-BfmLog 'ERREUR 37 : fermeture ou relance incomplete; verification DRI requise.'
        }
    }
}
if ($exitCode -eq 0) {
    Write-Host ''
    if ($value.freshLogin) {
        Write-Host 'Le client a enregistre le profil Etudiant apres soumission de son formulaire.'
    } else {
        Write-Host 'Le profil Etudiant etait deja present. Aucune nouvelle authentification forcee.'
    }
    Write-Host 'Client relance sans mode de debogage.'
    Write-Host ('Serveur : {0}:{1} ; compte : {2} ; role : {3}' -f $serverIp, $serverPort, $userName, $value.role)
    Write-Host 'Verifier la ferme dans le client, puis fermer et rouvrir pour confirmer la persistance.'
    Write-Host 'Cette configuration concerne uniquement la session Windows courante.'
}
if ($logFile) { Write-Host ('Journal : {0}' -f $logFile) }
exit $exitCode
